
# AI-Powered Insurance Claim Processor (Lightweight WordPress Plugin)

**What it is**
A lightweight, client-side simulated "AI" insurance claim processor.  
Built with vanilla PHP, HTML, and JavaScript. No external API calls required.

**Features**
- Shortcode: `[ai_claim_processor]` to embed UI in pages/posts.
- Client-side simulated processing and fraud-flagging heuristics.
- CSV export of processed claim report (client-side).
- PDF export via opening a printable view and using the browser's Print-to-PDF feature.
- Simple, modern UI and mobile responsive.

**Installation**
1. Upload the `ai-insurance-claim-processor` folder into `wp-content/plugins/`.
2. Activate the plugin in WordPress admin.
3. Add shortcode `[ai_claim_processor]` to any page or post.

**Notes & Future enhancements**
- Integrate with real claims APIs, document upload, and secure server-side processing for production.
- Add settings page for thresholds, email notifications, claim queue, and user roles.
- Add server-side PDF generation and storage.

**Disclaimer**
Results are AI-generated for educational use only. Always verify with experts and follow AI regulations.
