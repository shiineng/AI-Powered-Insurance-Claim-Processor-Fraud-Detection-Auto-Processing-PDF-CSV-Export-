
(function(){
    // Utilities
    function formatCurrency(n){ return '$' + n.toLocaleString(); }
    function getRandomInt(min, max){ return Math.floor(Math.random() * (max - min + 1)) + min; }

    function assessFraudRisk(data){
        // Simple heuristic-based scoring
        var score = 50; // base
        // suspicious if amount unusually large
        if(data.claimAmount > 20000) score += 20;
        if(data.claimAmount > 50000) score += 20;
        // old policy numbers or short patterns might be suspicious
        if(!/^POL/i.test(data.policyNumber)) score += 5;
        // recent policy (less than 30 days) increases risk
        if(data.policyAgeDays !== null && data.policyAgeDays < 30) score += 20;
        // multiple red flags: empty description, future date, numeric name
        if(!data.description || data.description.trim().length < 20) score += 10;
        if(new Date(data.dateOfLoss) > new Date()) score += 30;
        if(/\d/.test(data.claimantName)) score += 5;
        // randomness to simulate "AI"
        score += (Math.random() * 10 - 5);
        score = Math.max(0, Math.min(100, Math.round(score)));
        return score;
    }

    function classifyRisk(score){
        if(score >= 75) return {level:'High', cls:'flag-high', action:'Manual review recommended'};
        if(score >= 50) return {level:'Medium', cls:'flag-medium', action:'Further validation suggested'};
        return {level:'Low', cls:'flag-low', action:'Auto-approve possible'};
    }

    function simulateProcessing(data){
        // Simulate time and steps
        var steps = [
            'Validating policy and claimant details',
            'Checking claim history and recent activity',
            'Assessing documented evidence',
            'Running fraud heuristics & anomaly detection',
            'Estimating payout and reserves'
        ];
        // calculate policy age days (if policy number contains year pattern as heuristic)
        var policyAgeDays = data.policyAgeDays === null ? getRandomInt(60, 2000) : data.policyAgeDays;
        var fraudScore = assessFraudRisk(data);
        var risk = classifyRisk(fraudScore);

        // payout estimate: simple - base on claim amount and claim type
        var payoutMultiplier = (data.claimType === 'Auto') ? 0.85 : (data.claimType === 'Home') ? 0.9 : (data.claimType === 'Health') ? 0.8 : 0.75;
        var payout = Math.round(data.claimAmount * payoutMultiplier);

        return {
            steps: steps,
            policyAgeDays: policyAgeDays,
            fraudScore: fraudScore,
            risk: risk,
            payout: payout,
            adjudicator: (risk.level === 'High') ? 'Human Adjudicator' : 'Auto Adjudication Engine'
        };
    }

    function renderResult(data, report){
        var container = document.getElementById('ai-claim-results');
        if(!container) return;
        var html = '<h3>Processing result</h3>';
        html += '<p><strong>Policy:</strong> ' + data.policyNumber + ' &nbsp; <strong>Claimant:</strong> ' + data.claimantName + '</p>';
        html += '<table><tbody>';
        html += '<tr><th>Claim Type</th><td>' + data.claimType + '</td></tr>';
        html += '<tr><th>Claim Amount</th><td>' + formatCurrency(data.claimAmount) + '</td></tr>';
        html += '<tr><th>Date of Loss</th><td>' + (data.dateOfLoss || 'N/A') + '</td></tr>';
        html += '<tr><th>Payout Estimate</th><td>' + formatCurrency(report.payout) + '</td></tr>';
        html += '<tr><th>Fraud Score</th><td class="' + report.risk.cls + '">' + report.fraudScore + ' (' + report.risk.level + ')</td></tr>';
        html += '<tr><th>Adjudication</th><td>' + report.adjudicator + '</td></tr>';
        html += '<tr><th>Action</th><td>' + report.risk.action + '</td></tr>';
        html += '</tbody></table>';
        html += '<h4>Processing Steps</h4><ol>';
        report.steps.forEach(function(s){ html += '<li>' + s + '</li>'; });
        html += '</ol>';
        container.innerHTML = html;
    }

    function exportCSV(data, report){
        var header = ['Policy','Claimant','Type','ClaimAmount','PayoutEstimate','FraudScore','RiskLevel','Adjudicator','DateOfLoss'];
        var row = [
            data.policyNumber,
            data.claimantName,
            data.claimType,
            data.claimAmount,
            report.payout,
            report.fraudScore,
            report.risk.level,
            report.adjudicator,
            data.dateOfLoss
        ];
        var csv = header.join(',') + '\n' + row.join(',');
        var blob = new Blob([csv], { type: 'text/csv' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'claim_report.csv';
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
    }

    function exportPDF(data, report){
        var win = window.open('', '_blank');
        if(!win) return alert('Please allow popups to enable PDF export (Print-to-PDF).');
        var html = '<html><head><meta charset="utf-8"><title>Claim Report</title><style>body{font-family:Arial, sans-serif;padding:20px}table{width:100%;border-collapse:collapse}th,td{padding:8px;border:1px solid #ddd;text-align:left} .flag-high{color:#b91c1c;font-weight:700}</style></head><body>';
        html += '<h2>AI Claim Processor — Report</h2>';
        html += '<p><strong>Policy:</strong> ' + data.policyNumber + ' &nbsp; <strong>Claimant:</strong> ' + data.claimantName + '</p>';
        html += '<table><tbody>';
        html += '<tr><th>Claim Type</th><td>' + data.claimType + '</td></tr>';
        html += '<tr><th>Claim Amount</th><td>' + formatCurrency(data.claimAmount) + '</td></tr>';
        html += '<tr><th>Payout Estimate</th><td>' + formatCurrency(report.payout) + '</td></tr>';
        html += '<tr><th>Fraud Score</th><td>' + report.fraudScore + ' (' + report.risk.level + ')</td></tr>';
        html += '<tr><th>Adjudication</th><td>' + report.adjudicator + '</td></tr>';
        html += '</tbody></table>';
        html += '<h4>Processing Steps</h4><ol>';
        report.steps.forEach(function(s){ html += '<li>' + s + '</li>'; });
        html += '</ol>';
        html += '<p>Disclaimer: Results are AI-generated for educational use only. Always verify with experts.</p>';
        html += '</body></html>';
        win.document.open();
        win.document.write(html);
        win.document.close();
        setTimeout(function(){ win.print(); }, 600);
    }

    document.addEventListener('DOMContentLoaded', function(){
        var processBtn = document.getElementById('aiProcess');
        var resetBtn = document.getElementById('aiReset');
        var csvBtn = document.getElementById('exportCsv');
        var pdfBtn = document.getElementById('exportPdf');
        var lastData = null;
        var lastReport = null;

        function collectForm(){
            var policyNumber = document.getElementById('policyNumber').value || '';
            var claimantName = document.getElementById('claimantName').value || '';
            var claimType = document.getElementById('claimType').value || 'Auto';
            var claimAmount = parseFloat(document.getElementById('claimAmount').value) || 0;
            var dateOfLoss = document.getElementById('dateOfLoss').value || '';
            var description = document.getElementById('description').value || '';
            // simple policy age heuristic from policy number (if contains year like 2022)
            var yearMatch = policyNumber.match(/(19|20)\d{2}/);
            var policyAgeDays = null;
            if(yearMatch){
                var year = parseInt(yearMatch[0],10);
                var days = Math.floor((new Date() - new Date(year,0,1)) / (1000*60*60*24));
                policyAgeDays = days;
            }
            return {policyNumber, claimantName, claimType, claimAmount, dateOfLoss, description, policyAgeDays};
        }

        if(processBtn){
            processBtn.addEventListener('click', function(e){
                e.preventDefault();
                var data = collectForm();
                if(!data.policyNumber || !data.claimantName){
                    alert('Please fill policy number and claimant name.');
                    return;
                }
                var report = simulateProcessing(data);
                lastData = data;
                lastReport = report;
                renderResult(data, report);
            });
        }

        if(resetBtn){
            resetBtn.addEventListener('click', function(){
                document.getElementById('policyNumber').value = '';
                document.getElementById('claimantName').value = '';
                document.getElementById('claimAmount').value = 4500;
                document.getElementById('dateOfLoss').value = '';
                document.getElementById('description').value = '';
                document.getElementById('claimType').value = 'Auto';
                lastData = null; lastReport = null;
                var container = document.getElementById('ai-claim-results');
                if(container) container.innerHTML = '';
            });
        }

        if(csvBtn){
            csvBtn.addEventListener('click', function(){
                if(!lastData || !lastReport) return alert('No processed report to export.');
                exportCSV(lastData, lastReport);
            });
        }

        if(pdfBtn){
            pdfBtn.addEventListener('click', function(){
                if(!lastData || !lastReport) return alert('No processed report to export.');
                exportPDF(lastData, lastReport);
            });
        }
    });
})();
